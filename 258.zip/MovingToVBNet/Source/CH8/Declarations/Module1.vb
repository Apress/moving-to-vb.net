' Demonstration of declarations
' Copyright �2001 by Desaware Inc.
' All Rights Reserved
Module Module1

    Sub Main()
        Dim A, B As Integer
        Dim C As Integer = 6
        Dim D() As String = {"A", "B", "C", "D", "E"}
        Dim E As Integer, F As String
    End Sub

End Module