' Class library portion of namespaces demonstration
' Copyright �2001 by Desaware Inc. All Rights Reserved
Namespace MovingToVB.CH10.Organization.Members
    Public Class MemberSorter


    End Class
End Namespace

