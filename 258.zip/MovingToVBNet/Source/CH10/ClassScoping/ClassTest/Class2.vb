' Class scoping test program
' Copyright �2001 by Desaware Inc.  All Rights Reserved

Public Class Class2
    Dim p As PubIPub
    Dim p2 As PublicClass

    Sub Test()

    End Sub

End Class
