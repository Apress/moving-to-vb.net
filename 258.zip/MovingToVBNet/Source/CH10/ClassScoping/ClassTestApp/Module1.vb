' Class scoping test program
' Copyright �2001 by Desaware Inc.  All Rights Reserved

Imports MovingToVB.CH10.ClassScoping

Module Module1

    Sub Main()
        Dim p As PubIPub
        Dim p2 As PublicClass

    End Sub

End Module
