Option Strict Off
Option Explicit On
Module XOrMod
	
	Public Sub Main()
		Dim Var1 As Short
		Dim Result As Short
		
		Result = Var1 Xor 5
		
	End Sub
End Module