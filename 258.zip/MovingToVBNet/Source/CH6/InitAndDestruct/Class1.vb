' Initialization and Destruction example
' Copyright �2001 by Desaware Inc.

Public Class Class1
    Implements IDisposable
    Shared Sub New()
        MsgBox("Shared class initializer called")
    End Sub
    Protected Overrides Sub Finalize()
        MsgBox("My component finalizer called")
    End Sub

    Public Overridable Overloads Sub Dispose() Implements IDisposable.Dispose
        MsgBox("I've been disposed")
        ' Try with and without this line
        GC.SuppressFinalize(Me)
    End Sub

End Class
