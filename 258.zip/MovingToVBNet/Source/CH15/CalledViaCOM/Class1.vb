Imports System.Runtime.InteropServices
Public Interface _CallFromCOM
    Function TimesTwo(ByVal i As Integer) As Integer

End Interface
Public Class CallFromCOM
    Implements _CallFromCOM

    Public Function TimesTwo(ByVal i As Integer) As Integer Implements _CallFromCOM.TimesTwo
        Return i * 2
    End Function
    <ComRegisterFunction()> Public Shared Sub OnRegistration(ByVal T As Type)
        MsgBox("I'm being registered!!! :" & T.FullName)
    End Sub
End Class

