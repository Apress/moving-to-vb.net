Copy the StrongApp1.exe.config file to the bin directory to
set the upgrade policy for the assembly.
