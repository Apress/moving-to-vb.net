Imports strongDLL1
Module Module1

    Sub Main()
        Dim c As New strongDLL1.Class1()
        Console.WriteLine(c.MyVersion)
        Console.ReadLine()
    End Sub

End Module
