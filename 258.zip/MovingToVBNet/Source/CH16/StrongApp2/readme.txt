Copy the StrongApp2.exe.config file to the bin directory to add an 
upgrade policy to this application.