' Demo of very late binding
' Copyright �2001 by Desaware Inc. All Rights Reserved
Public Class LoadItDynamically
    Public Sub Test()
        MsgBox("The LoadItDyamically Test method was invoked", MsgBoxStyle.Information, "Important message")
    End Sub

End Class
