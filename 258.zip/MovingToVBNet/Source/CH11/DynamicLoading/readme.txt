Be sure to build the LaterBinding project before you try to run the
LateBindingCaller project
