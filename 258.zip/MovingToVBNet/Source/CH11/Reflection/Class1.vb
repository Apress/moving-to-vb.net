' Reflection and attributes example
' Copyright �2001 by Desaware Inc. All Rights Reserved

Public Class Class1

    Public Class TestClass
        Public X As Integer
        Private Y As Integer
    End Class

    Public Enum TestEnum
        FirstMember = 1
        SecondMember = 2
    End Enum
End Class
